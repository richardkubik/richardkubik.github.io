---
layout: post
title: "Gajdoš najradšej spomínal na Červenú hviezdu"
date: 2018-03-08
category: Sport
tags: [šport,osobnosti]
---



<img src="/images/gajdos.jpeg">

Slovan mal vyhliadnutého aj Gajdošovho kamaráta Jozefa Citaru. Tréner belasých Leopold „Jim“ Šťastný dal prezývku každému hráčovi. Gajdošovi sprvoti hovoril pomerne jednoducho Miro (skratka Kazimíra).

Potom však skomolil: Citara z Brusna neprišiel, tak sa Citarom stal Kazimír Gajdoš. Nie, nejde o hudobný nástroj. Slovensko nemalo až do čias Mariána Masného také výrazné pravé krídlo, akým bol Kazimír „Citara“ Gajdoš.

Nižší, rýchly s výbornou kľučkou. Asistujúci pri mnohých góloch, ale aj sám solídny zakončovateľ.

V poslednom zápase ročníka 1954/1955 potvrdil Slovan zisk titulu v derby s Červenou hviezdou Bratislava 3:1.

ČH bola, ako to inak nazvať, umelý klub, ktorý vznikol z úradnej moci. Stal sa však v Bratislave veľmi obľúbeným, hoci jeho história bola iba desaťročná.

Vznikol ako klub policajtov, v roku 1962 potom prešli hráči do TJ Slovnaft, od roku 1965 Inter Slovnaft.

Oba tituly, tak ako Gajdoš, získal už iba Pavol Molnár, hoci pri vzniku ČH odišlo do tohto klubu dosť hráčov Slovana.