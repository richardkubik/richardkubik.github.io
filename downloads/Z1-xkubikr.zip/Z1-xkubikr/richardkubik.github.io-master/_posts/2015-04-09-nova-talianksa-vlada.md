---
layout: post
title: "Nová Talianska vláda"
date: 2018-02-11
category: Politika
tags: [politika]
---



V nadväznosti na talianske parlamentné voľby, ktoré sa konali v nedeľu, predstaviteľ pravicovej strany Bratia Talianska poskytol rozhovor agentúre Sputnik.Roberto Jonghi Lavarini v ňom vyhlásil, že možná pravicová vláda sa okrem iného bude snažiť o zrušenie protiruských sankcií.„Budúca stredopravá vláda bude priateľská k Rusku a bude pracovať na zrušení ekonomických sankcií a obnovení privilegovaného dialógu s prezidentom Vladimírom Putinom a euroázijským svetom,“ uviedol Lavarini.Dodal tiež, že jeho strana požiada o revíziu všetkých medzinárodných zmlúv, vrátane tých, ktoré sa týkajú členstva Talianska v eurozóne a NATO a ktoré budú na prospech strategickej aliancie s euroáziou.
<img src="/images/italy.jpg">