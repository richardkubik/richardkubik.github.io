---
layout: post
title: "Marec nás poriadne poskúša"
date: 2018-02-28
category: Pocasie
tags: [počasie]
---
<img width="300px" height="500" src="/images/march.jpg">
<p>Vstúpili sme do veľmi silného mesiaca. A tak sa nečudujme, že začneme zažívať veľmi silné útoky na naše slabé stránky. Veď ako inak by sme dokázali zmeniť vlastné koleso osudu, uvoľniť to nepotrebné z minulosti, poučiť sa a nabrať poučenie, novosť života.</p>


Dnes máme spln a čaká nás ešte silnejší spln 31.3. Od tohto splnu každý spln v tomto roku nás povedie vo veľmi silnom božskom dokončovacom móde.




31.3.2018=(9)


30.4.2018=(9)


29.5.2018=(9)


28.6.2018=(9)


27.7.2018=(9)


26.8.2018=(9)


25.9.2018=(9)


24.10.2018=(9)


23.11.2018=(9)


22.12.2018=(9)






Niet sa čo čudovať. Vstúpili sme do vyššieho levelu transformácie. Od teraz budeme zažívať nie len stále vyššie vibračné skoky prichádzajúcich  energií lásky, no vyzerá to tak, že podľa osobných potrieb aj zvraty na všetkých úrovniach bytia človečenstva.


Minulosť by sme mali definitívne prepustiť a sústrediť sa na našu prítomnosť. Zbytočne hľadáme aj vzhľady do budúcnosti. Tá sa tvorí teraz v prítomnosti a pokiaľ stále chceme postupovať cez istotu ega v tvorbe budúcnosti, ľahko sa pošmykneme a dostaneme sa na inú koľaj životného plánu.