---
nazov: Paralelné prog
predmet: PP
rok: 2017
jazyk: cecko
---