---
nazov: Malloc Simulation
predmet: PP
rok: 2015
jazyk: cecko
---