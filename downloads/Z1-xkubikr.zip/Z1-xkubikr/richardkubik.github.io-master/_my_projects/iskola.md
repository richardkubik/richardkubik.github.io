---
nazov: Inteligentná škola
predmet: MSOFT
rok: 2017
jazyk: Java
---