---
nazov: FunnyThing
predmet: AZA
rok: 2016
jazyk: C++
---