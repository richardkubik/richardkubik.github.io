---
nazov: EntityManager
predmet: OOP
rok: 2015
jazyk: Java
---