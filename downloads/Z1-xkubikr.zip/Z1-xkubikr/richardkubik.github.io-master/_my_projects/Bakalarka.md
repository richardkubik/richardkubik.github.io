---
nazov: Bakalarka
predmet: ---
rok: 2018
jazyk: Java
---