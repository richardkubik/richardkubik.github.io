---
nazov: UDP Komunikátor
predmet: PKS
rok: 2016
jazyk: Java
---