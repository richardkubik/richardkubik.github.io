---
nazov: Client-Server Communication
predmet: ASM
rok: 2017
jazyk: ASM
---