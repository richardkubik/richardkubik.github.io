---
nazov: DBManager
predmet: DBS
rok: 2016
jazyk: Java
---