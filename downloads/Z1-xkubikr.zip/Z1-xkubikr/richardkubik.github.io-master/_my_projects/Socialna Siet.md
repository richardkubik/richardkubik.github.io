---
nazov: Socialna siet
predmet: DSA
rok: 2016
jazyk: cecko
---