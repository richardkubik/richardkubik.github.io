---
nazov: Popolvar
predmet: DSA
rok: 2016
jazyk: cecko
---